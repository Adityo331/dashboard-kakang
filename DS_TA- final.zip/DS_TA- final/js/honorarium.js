addHonorarium();
editHonorarium();
deleteHonorarium();
renderHonorarium();
